<div id="footer">
<p>Powered By <a href="http://www.wordpress.org">WordPress</a>
</p>
</div>
<div class="pusher"></div>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
