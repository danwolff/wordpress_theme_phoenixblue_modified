<div id="footer">
<p>
</p>
</div>
<div class="pusher"></div>
</div>

<?php do_action('wp_footer'); ?>

</body>
</html>
